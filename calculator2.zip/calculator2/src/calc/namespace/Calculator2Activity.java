package calc.namespace;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Calculator2Activity extends Activity {
    /** Called when the activity is first created. */
	final int MENU_ABOUT_ID = 1;
	final int MENU_RESET_ID=2;
	final int MENU_QUIT_ID = 3;
	
	EditText numview;
	Button add;
	Button sub;
	Button mult;
	Button div;
	Button ishora;
	Button leftqavs;
	Button rightqavs;
	Button sbros;
	Button kv;
	Button ildiz;
	Button drj;
	Button idrj;
	Button natija;
	
	float num1=0;
	float num2=0;
	float result=0;
	
    int check=0;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        numview=(EditText) findViewById(R.id.numview);
        add = (Button) findViewById(R.id.add);
        sub = (Button) findViewById(R.id.sub);
        mult = (Button) findViewById(R.id.mult);
        div = (Button) findViewById(R.id.div);
        ishora = (Button) findViewById(R.id.ishora);
        leftqavs = (Button) findViewById(R.id.leftqavs);
        rightqavs = (Button) findViewById(R.id.rightqavs);
        sbros = (Button) findViewById(R.id.sbros);
        kv = (Button) findViewById(R.id.kv);
        ildiz = (Button) findViewById(R.id.ildiz);
        drj = (Button) findViewById(R.id.drj);
        idrj = (Button) findViewById(R.id.idrj);
        natija = (Button) findViewById(R.id.natija);
                
        OnClickListener ocladd = new OnClickListener() {
        	//@Override	
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				
			  if (TextUtils.isEmpty(numview.getText().toString()))
			      {
			  return;
			  }
			  num1 = Float.parseFloat(numview.getText().toString());
			  numview.setText("");			  
			  check=1;
						 
			}
       	};
	     
	add.setOnClickListener(ocladd);
	
	OnClickListener oclsub = new OnClickListener() {
    	//@Override	
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			
			
		  if (TextUtils.isEmpty(numview.getText().toString()))
		      {
		  return;
		  }
		  num1 = Float.parseFloat(numview.getText().toString());
		  numview.setText("");			  
		  check=2;
					 
		}
   	};
     
sub.setOnClickListener(oclsub);

OnClickListener ocldiv = new OnClickListener() {
	//@Override	
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
		
	  if (TextUtils.isEmpty(numview.getText().toString()))
	      {
	  return;
	  }
	  num1 = Float.parseFloat(numview.getText().toString());
	  numview.setText("");			  
	  check=3;
				 
	}
	};
 
div.setOnClickListener(ocldiv);

OnClickListener oclmult = new OnClickListener() {
	//@Override	
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
		
	  if (TextUtils.isEmpty(numview.getText().toString()))
	      {
	  return;
	  }
	  num1 = Float.parseFloat(numview.getText().toString());
	  numview.setText("");		  
	  check=4;
				 
	}
	};
 
mult.setOnClickListener(oclmult);
        
OnClickListener oclnatija = new OnClickListener() {
	//@Override	
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
		
	  if (TextUtils.isEmpty(numview.getText().toString()))
	      {
	  return;
	  }
	  num2 = Float.parseFloat(numview.getText().toString());
	  if (check==1){
		  result=num1+num2;
	  }			  
	  	
	  if (check==2){
		  result=num1-num2;
	  }	
	  
	  if (check==3){
		  result=num1/num2;
	  }	
	  
	  if (check==4){
		  result=num1*num2;
	  }	
	  
	  numview.setText(""+result);
	}
	};
 
natija.setOnClickListener(oclnatija);

OnClickListener oclsbros = new OnClickListener() {
	//@Override	
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
		 
	  numview.setText("");		  
	  				 
	}
	};
 
sbros.setOnClickListener(oclsbros);

    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    // TODO Auto-generated method stub
    menu.add(0, MENU_ABOUT_ID, 0, "Informatsiya");
    menu.add(0, MENU_RESET_ID, 0, "Yangilash");
    menu.add(0, MENU_QUIT_ID, 0, "Chiqish");
    return super.onCreateOptionsMenu(menu);
    }

    // ��������� ������� �� ������ ����
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    // TODO Auto-generated method stub
    switch (item.getItemId()) {
    case MENU_ABOUT_ID:
        // ������� ����
        numview.setTextSize(18);
      
    	numview.setText("Copyright by akuware@mail.ru");
    	
        break;
    case MENU_RESET_ID:
    // ������� ����
    	numview.setTextSize(28);
    	numview.setText("");
    break;
    case MENU_QUIT_ID:
    // ����� �� ����������
    finish();
    break;
    }
    return super.onOptionsItemSelected(item);
    }
}